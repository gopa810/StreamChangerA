﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.Xml;
using System.Diagnostics;
using StreamChangerLib;

namespace StreamChangerA
{
    public partial class Form1 : Form
    {
        ListToTreeConvertor cnc = new ListToTreeConvertor();

        public Form1()
        {
            InitializeComponent();

            string appdir = Path.GetDirectoryName(Application.ExecutablePath);

            cnc.Load(Path.Combine(appdir, "cscript.txt"));

            if (File.Exists(Path.Combine(appdir, "cscript2.txt")))
                cnc.LoadText(Path.Combine(appdir, "cscript2.txt"));

            InitTabC();

        }

        private void InitTabC()
        {
            updateProcCTransList();
            updateProcCUndefList();
        }

        private void updateProcCTransList()
        {
            listBox1.Sorted = false;
            listBox1.BeginUpdate();
            listBox1.Items.Clear();
            foreach (string s in cnc.TransRulesRaw.Keys)
            {
                listBox1.Items.Add(s);
            }
            listBox1.EndUpdate();
            listBox1.Sorted = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string appdir = Path.GetDirectoryName(Application.ExecutablePath);
            string temp;

            StreamToTable stt = new StreamToTable();

            stt.Script = File.ReadAllText(Path.Combine(appdir, "ascript.txt"));
            stt.InputText = File.ReadAllText(Path.Combine(appdir, "ainp.txt")) + "\r\n";

            stt.Run();

            if (!stt.Success)
                temp = stt.InputText.Substring(stt.LastPosition);
            else
                temp = "";

            File.WriteAllText(Path.Combine(appdir, "aui.txt"), temp);
            stt.Elements.WriteXml(Path.Combine(appdir, "aout.xml"));
            File.WriteAllText(Path.Combine(appdir, "amsg.txt"), stt.Message);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string appdir = Path.GetDirectoryName(Application.ExecutablePath);

            ExtractComments ec = new ExtractComments();

            SourceNodeCollection snc = new SourceNodeCollection();

            snc.ReadXml(Path.Combine(appdir, "aout.xml"));
            ec.InputSource = snc;

            ec.Rules = "comment comment\ncomment comment_inline\nspace spaces\nnewline newline";


            ec.Run();

            if (ec.Success)
            {
                ec.OutputSource.WriteXml(Path.Combine(appdir, "bsrc.xml"));
                File.WriteAllText(Path.Combine(appdir, "bmsg.txt"), ec.Message);
            }
            else
            {
                File.WriteAllText(Path.Combine(appdir, "bmsg.txt"), ec.Message);
            }


        }

        private void button3_Click(object sender, EventArgs e)
        {
            string appdir = Path.GetDirectoryName(Application.ExecutablePath);

            //ListToTreeConvertor cnc = new ListToTreeConvertor();
            SourceNodeCollection snc = new SourceNodeCollection();

            snc.ReadXml(Path.Combine(appdir, "aout2.xml"));
            cnc.InputSource = snc;

            cnc.LooseConversion = false;
            cnc.InputFilterTypesRemove.Add("spaces");
            cnc.InputFilterTypesRemove.Add("newline");
            cnc.InputFilterTypesRemove.Add("comment");
            cnc.InputFilterTypesRemove.Add("comment_inline");

            cnc.Run();

            //cnc.OutputSource.WriteXml(Path.Combine(appdir, "csrc.xml"));
            cnc.Save(Path.Combine(appdir, "cscript.txt"));
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0 && listBox1.SelectedIndex < listBox1.Items.Count)
            {
                string term = listBox1.Items[listBox1.SelectedIndex] as string;
                string rawDef = cnc.TransRulesRaw[term];

                textBox1.Text = term;
                richTextBox1.Text = rawDef;

                button4.Enabled = false;

                updateProcCTree(term, rawDef);
            }
        }


        private void updateProcCTree(string term, string definition)
        {
            TransNode tn = cnc.TransNodeFromString(term, definition);

            TreeNode node = TreeNodeFromTransNode(tn);

            treeView1.Nodes.Clear();
            treeView1.Nodes.Add(node);
            treeView1.ExpandAll();
        }

        private TreeNode TreeNodeFromTransNode(TransNode tn)
        {
            TreeNode node = new TreeNode(string.Format("{0} [{1}:{2}]", tn.value == null ? "" : tn.value, tn.min, tn.max));
            switch (tn.type)
            {
                case "GROUP":
                    node.ImageIndex = 0;
                    break;
                case "LIST":
                    node.ImageIndex = 1;
                    break;
                case "TERM":
                    node.ImageIndex = 2;
                    break;
                case "TYPE":
                    node.ImageIndex = 3;
                    break;
                case "CONST":
                    node.ImageIndex = 4;
                    break;
                default:
                    break;
            }
            node.SelectedImageIndex = node.ImageIndex;
            if (tn.Nodes != null && tn.Nodes.Count > 0)
            {
                for (int j = 0; j < tn.Nodes.Count; j++)
                {
                    TransNode sub1 = tn.Nodes[j];
                    TreeNode node2 = TreeNodeFromTransNode(sub1);
                    node.Nodes.Add(node2);
                }
            }

            return node;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string s = textBox1.Text;
            bool existing = CurrentTermExists();

            if (existing)
            {
                button4.Enabled = false;
                richTextBox1.Text = cnc.TransRulesRaw[s];
            }
            else
            {
                button4.Enabled = true;
                richTextBox1.Text = "";
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            cnc.AddDefinition(textBox1.Text, richTextBox1.Text);

            button4.Enabled = !CurrentTermExists();
            updateProcCTransList();
            updateProcCUndefList();
        }

        private void updateProcCUndefList()
        {
            Dictionary<string, HashSet<string>> usedTerms = new Dictionary<string, HashSet<string>>();

            foreach (string key in cnc.TransRules.Keys)
            {
                fillUsedTerms(cnc.TransRules[key], usedTerms, key);
            }

            listBox2.BeginUpdate();
            listBox2.Sorted = false;
            listBox2.Items.Clear();
            foreach (string ut in usedTerms.Keys)
            {
                if (cnc.TransRules.ContainsKey(ut) == false)
                {
                    StringBuilder sb = new StringBuilder();
                    sb.AppendFormat("{0} => ", ut);
                    foreach (string s in usedTerms[ut])
                    {
                        sb.AppendFormat("{0}, ", s);
                    }
                    listBox2.Items.Add(sb.ToString());
                }
            }
            listBox2.Sorted = true;
            listBox2.EndUpdate();


        }

        private void fillUsedTerms(TransNode node, Dictionary<string,HashSet<string>> terms, string name)
        {
            if (node.Nodes == null)
                return;

            for (int j = 0; j < node.Nodes.Count; j++)
            {
                TransNode tn = node.Nodes[j];
                if (tn.type.Equals("TERM"))
                {
                    if (terms.ContainsKey(tn.value))
                    {
                        terms[tn.value].Add(name);
                    }
                    else
                    {
                        HashSet<string> vals = new HashSet<string>();
                        vals.Add(name);
                        terms.Add(tn.value, vals);
                    }
                }
                fillUsedTerms(tn, terms, name);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string appdir = Path.GetDirectoryName(Application.ExecutablePath);

            cnc.Save(Path.Combine(appdir, "cscript.txt"));

            cnc.SaveText(Path.Combine(appdir, "cscript2.txt"));
        }

        private bool CurrentTermExists()
        {
            return cnc.TransRules.ContainsKey(textBox1.Text);
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (CurrentTermExists())
            {
                cnc.TransRulesRaw[textBox1.Text] = richTextBox1.Text;
                cnc.TransRules[textBox1.Text] = cnc.TransNodeFromString(textBox1.Text, richTextBox1.Text);
            }

            updateProcCTree(textBox1.Text, richTextBox1.Text);
            updateProcCUndefList();
        }

        private void listBox2_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            int idx = listBox2.IndexFromPoint(new Point(e.X, e.Y));
            if (idx >= 0 && idx < listBox2.Items.Count)
            {
                string k = listBox2.Items[idx] as string;
                string[] pp = k.Split(new string[] { "=>" }, StringSplitOptions.RemoveEmptyEntries);
                textBox1.Text = pp[0].Trim();
            }
        }
    }
}
